using System;
using System.IO;
using Newtonsoft.Json;
using NUnit.Framework;

namespace SimDataExtractor.IntegrationTests
{
    internal static class RunWorkerTestCases
    {
        internal static string ExportHdf5(string simPath)
        {
            string runJournalExe = RequiredFile("NX_RUN_JOURNAL");
            string workerDll = RequiredFile("NX_WORKER_DLL");

            if (!File.Exists(simPath))
                throw new FileNotFoundException("Beam SIM fixture is missing.", simPath);

            string cachePath = simPath + ".meshcache.json";
            if (!File.Exists(cachePath))
                throw new FileNotFoundException(
                    "Open this SIM in NX and run SimDataExtractor once to generate its body/domain cache.",
                    cachePath);

            string runDir = Path.Combine(Path.GetTempPath(), "SimDataExtractor.Tests",
                                         Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(runDir);
            TestContext.Out.WriteLine($"NX worker DLL: {workerDll}");
            TestContext.Out.WriteLine($"NX run artifacts: {runDir}");

            var job = new WorkerExtractionJob
            {
                SimPath = simPath,
                CachePath = cachePath,
                OutputH5Path = Path.Combine(runDir, "beam.h5"),
                BoundaryFacePath = Path.Combine(runDir, "beam.boundary_faces.json"),
                HeartbeatPath = Path.Combine(runDir, "beam.heartbeat"),
                HasVisibilitySnapshot = false,
                TimeoutMinutes = 15
            };

            // This fixture has no registered boundary faces.
            File.WriteAllText(job.BoundaryFacePath, "{\"Faces\":[]}");
            string jobPath = Path.Combine(runDir, "beam.extraction_job.json");
            File.WriteAllText(jobPath, JsonConvert.SerializeObject(job, Formatting.Indented));

            LaunchWorkerBatchMode.Run(runJournalExe, workerDll, jobPath, job);
            return job.OutputH5Path;
        }

        private static string RequiredFile(string setting)
        {
            string path = Environment.GetEnvironmentVariable(setting);
            if (!File.Exists(path))
                throw new FileNotFoundException($"Set {setting} to the full path of an existing file.", path);
            return Path.GetFullPath(path);
        }
    }

    // These property names form the worker's on-disk JSON contract.
    internal sealed class WorkerExtractionJob
    {
        public string SimPath { get; set; }
        public string CachePath { get; set; }
        public string OutputH5Path { get; set; }
        public string BoundaryFacePath { get; set; }
        public string HeartbeatPath { get; set; }
        public bool HasVisibilitySnapshot { get; set; }
        public int TimeoutMinutes { get; set; }
    }
}
