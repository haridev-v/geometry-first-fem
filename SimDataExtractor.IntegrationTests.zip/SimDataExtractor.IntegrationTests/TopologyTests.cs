using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using HDF.PInvoke;
using NUnit.Framework;
using YamlDotNet.RepresentationModel;

namespace SimDataExtractor.IntegrationTests
{
    [TestFixture]
    [Category("NXIntegration")]
    [NonParallelizable]
    public sealed class TopologyTests
    {
        private const string BeamCase = "Node_elem_count_beam_f1";
        private const string BeamSim = "node_elem_count_beam_s1.sim";

        [Test]
        public void BeamMeshMatchesInfoYaml()
        {
            string dir = Environment.GetEnvironmentVariable("NX_TOPOLOGY_CASE_DIR");
            if (!Directory.Exists(dir))
                throw new DirectoryNotFoundException("Set NX_TOPOLOGY_CASE_DIR to the folder containing INFO.yaml and the beam SIM.");

            dir = Path.GetFullPath(dir);
            var yaml = new YamlStream();
            using (var reader = File.OpenText(Path.Combine(dir, "INFO.yaml")))
                yaml.Load(reader);

            var expected = Map((YamlMappingNode)yaml.Documents.Single().RootNode, BeamCase);
            string exportPath = RunWorkerTestCases.ExportHdf5(Path.Combine(dir, BeamSim));
            AssertExport(exportPath, expected);
        }

        internal static void AssertExport(string h5Path, YamlMappingNode expected)
        {
            int nodes = Number(expected, "Num Nodes");
            int elements = Number(expected, "Num Elems");
            int volumeMarkers = Number(expected, "Volume markers");
            int facetMarkers = Number(expected, "Facet Markers");
            string expectedShape = Scalar(expected, "Shape");
            int expectedOrder = Number(expected, "Order");

            var semantics = Map(expected, "Semantics");
            string coordsPath = Scalar(semantics, "Coordinates");
            string cellsPath = Scalar(semantics, "Volume Markers Topology");
            string volumeValuesPath = Scalar(semantics, "Volume Marker Values");
            string facetsPath = Scalar(semantics, "Facet Marker Topology");
            string facetValuesPath = Scalar(semantics, "Facet Marker Values");

            var file = H5F.open(h5Path, H5F.ACC_RDONLY);
            Assert.That(file, Is.GreaterThanOrEqualTo(0), $"Cannot open HDF5 file {h5Path}");
            try
            {
                var coords = Read(coordsPath, false);
                Assert.That(coords.Dimensions, Is.EqualTo(new ulong[] { (ulong)nodes, 3 }), coordsPath);
                Assert.That(Array.FindIndex((double[])coords.Values,
                    x => double.IsNaN(x) || double.IsInfinity(x)), Is.EqualTo(-1),
                    $"{coordsPath} contains a non-finite coordinate.");

                var cells = Read(cellsPath, true);
                Assert.That(cells.Dimensions.Length, Is.EqualTo(2), cellsPath);
                Assert.That(cells.Dimensions[0], Is.EqualTo((ulong)elements), "Num Elems");
                var topology = VolumeTopology(cells.Dimensions[1]);
                Assert.That(topology.Shape, Is.EqualTo(expectedShape).IgnoreCase, "Shape");
                Assert.That(topology.Order, Is.EqualTo(expectedOrder), "Order");
                AssertNodeIndices((long[])cells.Values, nodes, cellsPath);
                AssertMarkers(Read(volumeValuesPath, true), (ulong)elements, volumeMarkers, volumeValuesPath);

                bool hasFacets = Exists(facetsPath);
                bool hasFacetValues = Exists(facetValuesPath);
                Assert.That(hasFacets, Is.EqualTo(hasFacetValues), "Facet topology and Values must occur together.");
                if (!hasFacets)
                {
                    Assert.That(facetMarkers, Is.Zero, $"Missing {facetsPath} and {facetValuesPath}");
                    return;
                }

                var facets = Read(facetsPath, true);
                Assert.That(facets.Dimensions.Length, Is.EqualTo(2), facetsPath);
                Assert.That(facets.Dimensions[1], Is.EqualTo(topology.FacetWidth), facetsPath);
                AssertNodeIndices((long[])facets.Values, nodes, facetsPath);
                AssertMarkers(Read(facetValuesPath, true), facets.Dimensions[0], facetMarkers, facetValuesPath);
            }
            finally
            {
                H5F.close(file);
            }

            bool Exists(string path)
            {
                string prefix = "";
                foreach (string name in path.Split(new[] { '/' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    prefix += "/" + name;
                    int status = H5L.exists(file, prefix, H5P.DEFAULT);
                    Assert.That(status, Is.GreaterThanOrEqualTo(0), $"Cannot inspect {prefix}");
                    if (status == 0)
                        return false;
                }

                return true;
            }

            (ulong[] Dimensions, Array Values) Read(string path, bool integer)
            {
                var dataset = H5D.open(file, path);
                Assert.That(dataset, Is.GreaterThanOrEqualTo(0), $"Missing or unreadable dataset {path}");
                var space = H5D.get_space(dataset);
                var type = H5D.get_type(dataset);
                try
                {
                    Assert.That(space, Is.GreaterThanOrEqualTo(0), $"Cannot read dataspace for {path}");
                    Assert.That(type, Is.GreaterThanOrEqualTo(0), $"Cannot read datatype for {path}");
                    var expectedType = integer ? H5T.class_t.INTEGER : H5T.class_t.FLOAT;
                    Assert.That(H5T.get_class(type), Is.EqualTo(expectedType), path);

                    int rank = H5S.get_simple_extent_ndims(space);
                    Assert.That(rank, Is.GreaterThanOrEqualTo(0), path);
                    var dims = new ulong[rank];
                    if (rank > 0)
                        Assert.That(H5S.get_simple_extent_dims(space, dims, null), Is.EqualTo(rank), path);

                    long points = H5S.get_simple_extent_npoints(space);
                    Assert.That(points, Is.InRange(0L, (long)int.MaxValue), path);
                    int count = (int)points;
                    Array values = integer ? (Array)new long[count] : new double[count];
                    if (count > 0)
                    {
                        var buffer = GCHandle.Alloc(values, GCHandleType.Pinned);
                        try
                        {
                            var nativeType = integer ? H5T.NATIVE_LLONG : H5T.NATIVE_DOUBLE;
                            int status = H5D.read(dataset, nativeType, H5S.ALL, H5S.ALL,
                                                  H5P.DEFAULT, buffer.AddrOfPinnedObject());
                            Assert.That(status, Is.GreaterThanOrEqualTo(0), $"Cannot read {path}");
                        }
                        finally
                        {
                            buffer.Free();
                        }
                    }

                    return (dims, values);
                }
                finally
                {
                    if (type >= 0) H5T.close(type);
                    if (space >= 0) H5S.close(space);
                    H5D.close(dataset);
                }
            }
        }

        private static (string Shape, int Order, ulong FacetWidth) VolumeTopology(ulong width)
        {
            switch (width)
            {
                case 4: return ("Tetrahedron", 1, 3UL);
                case 10: return ("Tetrahedron", 2, 6UL);
                case 8: return ("Hexahedron", 1, 4UL);
                default: throw new AssertionException($"Unsupported volume topology width {width}.");
            }
        }

        private static void AssertNodeIndices(long[] connectivity, int nodes, string path)
        {
            int bad = Array.FindIndex(connectivity, i => i < 0 || i >= nodes);
            if (bad >= 0)
                Assert.Fail($"{path} index at offset {bad} is {connectivity[bad]}, outside [0, {nodes}).");
        }

        private static void AssertMarkers((ulong[] Dimensions, Array Values) dataset,
                                          ulong rows, int distinctCount, string path)
        {
            ulong[] dims = dataset.Dimensions;
            Assert.That(dims.Length == 1 || (dims.Length == 2 && dims[1] == 1), Is.True,
                        $"{path} must have shape (N) or (N, 1).");
            Assert.That(dims[0], Is.EqualTo(rows), $"{path} must have one value per topology row.");
            var ids = (long[])dataset.Values;
            Assert.That(Array.FindIndex(ids, id => id <= 0), Is.EqualTo(-1),
                        $"{path} contains a non-positive marker ID.");
            Assert.That(ids.Distinct().Count(), Is.EqualTo(distinctCount), $"{path} distinct marker IDs");
        }

        private static YamlNode Required(YamlMappingNode map, string key)
        {
            if (map.Children.TryGetValue(new YamlScalarNode(key), out var value))
                return value;
            throw new InvalidDataException($"INFO.yaml is missing '{key}'.");
        }

        private static YamlMappingNode Map(YamlMappingNode parent, string key) =>
            Required(parent, key) as YamlMappingNode ??
                throw new InvalidDataException($"INFO.yaml '{key}' must be a mapping.");

        private static string Scalar(YamlMappingNode parent, string key)
        {
            var node = Required(parent, key) as YamlScalarNode;
            if (string.IsNullOrWhiteSpace(node?.Value))
                throw new InvalidDataException($"INFO.yaml '{key}' must be a scalar value.");
            return node.Value;
        }

        private static int Number(YamlMappingNode parent, string key)
        {
            if (int.TryParse(Scalar(parent, key), NumberStyles.Integer, CultureInfo.InvariantCulture,
                             out int number) && number >= 0)
                return number;
            throw new InvalidDataException($"INFO.yaml '{key}' must be a non-negative integer.");
        }
    }
}
