# SimDataExtractor integration tests

`BeamMeshMatchesInfoYaml` tests an existing `SimDataExtractor.dll` on Windows. The NUnit project builds on its own. It passes a JSON job to the NX worker, then checks the HDF5 file from that run against the beam case in `INFO.yaml`.

## Run against a built DLL

1. Keep the extractor DLL in its working build or deployment directory with its runtime dependencies. Use a licensed NX installation compatible with that build.
2. Point `NX_TOPOLOGY_CASE_DIR` at the folder containing your `INFO.yaml` and `node_elem_count_beam_s1.sim`. Keep the referenced FEM and part files available in their existing layout. If the SIM's `.meshcache.json` sidecar is missing or cannot be restored after moving the fixture, open the SIM as the work part in NX, launch the existing extractor, and let the initial model scan finish.
3. Set the three absolute paths in `mesh-topology.runsettings`. `NX_WORKER_DLL` identifies the build under test. `NX_RUN_JOURNAL` identifies the NX batch executable. `NX_TOPOLOGY_CASE_DIR` identifies the fixture folder.
4. From this directory, use the Windows x64 .NET SDK to restore, build, and run the test. The project targets .NET Framework 4.8.

```powershell
dotnet test .\SimDataExtractor.IntegrationTests.csproj --settings .\mesh-topology.runsettings
```

In Visual Studio, open the project, select the runsettings file under **Test → Configure Run Settings**, and run `BeamMeshMatchesInfoYaml` in Test Explorer. Test output records the DLL path and the temporary directory containing the JSON job, heartbeat, and export.

The DLL is loaded by `run_journal.exe`, which calls `SimDataExtractor.NXProgram.RunWorkerExtraction(string jobPath)` in the NX process. The launcher accepts that static method with either public or non-public visibility. The method and job JSON fields are the runtime interface for this test. If the test host reports an HDF5 DLL load error, check the test output's `bin64` directory for the native HDF5 libraries from its HDF.PInvoke NuGet package. The NX worker uses the dependencies of the selected extractor build.

## Add source-level unit tests later

Add a sibling `SimDataExtractor.UnitTests` project to the source solution with a project reference to `SimDataExtractor.csproj`. Use it for direct calls to code such as connectivity remapping. Add this integration project to the same solution if you want both suites in Test Explorer. To test a fresh source build end to end, build the extractor and point `NX_WORKER_DLL` at its output. The same integration test can run against a release build or a local build.

The beam assertions use the YAML key `Node_elem_count_beam_f1`. The project was checked for references, settings, and worker job fields. The HDF5 rules were exercised against 14 synthetic exports. The .NET Framework build and licensed NX run still need verification on Windows.
