using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;

namespace SimDataExtractor.IntegrationTests
{
    internal static class LaunchWorkerBatchMode
    {
        internal static void Run(string runJournalExe, string workerDll,
                                 string jobPath, WorkerExtractionJob job)
        {
            string journalPath = Path.Combine(Path.GetDirectoryName(jobPath), "WorkerLaunch.vb");
            File.WriteAllText(journalPath, $@"Option Strict On
Imports System
Imports System.IO
Imports System.Reflection

Module WorkerLaunch
    Sub Main()
        Dim jobPath As String = {VbString(jobPath)}
        Dim errorPath As String = jobPath & "".error""
        Try
            Dim workerAssembly As Assembly = Assembly.LoadFrom({VbString(workerDll)})
            Dim program As Type = workerAssembly.GetType(""SimDataExtractor.NXProgram"", True)
            Dim method As MethodInfo = program.GetMethod(""RunWorkerExtraction"", _
                BindingFlags.Static Or BindingFlags.Public Or BindingFlags.NonPublic, _
                Nothing, New Type() {{GetType(String)}}, Nothing)
            If method Is Nothing OrElse method.ReturnType IsNot GetType(Integer) Then
                Throw New MissingMethodException(program.FullName, ""RunWorkerExtraction(String) As Integer"")
            End If
            Dim code As Integer = CInt(method.Invoke(Nothing, New Object() {{jobPath}}))
            If code <> 0 Then
                Throw New InvalidOperationException(""RunWorkerExtraction returned "" & code.ToString())
            End If
        Catch ex As Exception
            If Not File.Exists(errorPath) Then
                File.WriteAllText(errorPath, ex.GetBaseException().ToString())
            End If
            Throw
        End Try
    End Sub
End Module
");

            var start = new ProcessStartInfo
            {
                FileName = runJournalExe,
                Arguments = "\"" + journalPath + "\"",
                WorkingDirectory = Path.GetDirectoryName(journalPath),
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };

            using (var worker = Process.Start(start) ??
                                throw new InvalidOperationException("Could not start run_journal.exe."))
            {
                var stdout = worker.StandardOutput.ReadToEndAsync();
                var stderr = worker.StandardError.ReadToEndAsync();

                if (!worker.WaitForExit(checked(job.TimeoutMinutes * 60 * 1000)))
                {
                    try { worker.Kill(); }
                    catch (InvalidOperationException) { }
                    worker.WaitForExit(5000);
                    throw new TimeoutException(
                        $"NX worker exceeded {job.TimeoutMinutes} minutes.\n" +
                        $"Last heartbeat: {ReadIfPresent(job.HeartbeatPath)}\nJob: {jobPath}");
                }

                string errorPath = jobPath + ".error";
                bool hasSuccess = File.Exists(jobPath + ".success");
                bool hasExport = File.Exists(job.OutputH5Path);
                if (worker.ExitCode != 0 || File.Exists(errorPath) ||
                    !hasSuccess || !hasExport)
                {
                    Task.WaitAll(new Task[] { stdout, stderr }, 5000);
                    throw new InvalidOperationException(
                        $"NX export failed (exit {worker.ExitCode}).\nJob: {jobPath}\n" +
                        $"Success marker present: {hasSuccess}. HDF5 present: {hasExport}.\n" +
                        $"Worker error: {ReadIfPresent(errorPath)}\n" +
                        $"Last heartbeat: {ReadIfPresent(job.HeartbeatPath)}\n" +
                        $"stdout: {CompletedOutput(stdout)}\nstderr: {CompletedOutput(stderr)}");
                }
            }
        }

        private static string VbString(string value) => "\"" + value.Replace("\"", "\"\"") + "\"";

        private static string ReadIfPresent(string path) =>
            File.Exists(path) ? File.ReadAllText(path) : "(none)";

        private static string CompletedOutput(Task<string> task) =>
            task.Status == TaskStatus.RanToCompletion ? task.Result : "(output stream still open)";
    }
}
